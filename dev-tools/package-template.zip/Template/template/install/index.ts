const install = () => {
  // TODO: Install
};

export default install;
