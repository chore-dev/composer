import {
  createCheckbox,
  createCheckboxChoice,
  massageChoices
} from '../../../src/utilities/inquirer';
import { SimplifiedChoices } from '../../../types';

export const CHOICES = [
  ['Install dependencies', 'install', 'Install', true],
  ['Insert scripts', 'insertScripts', 'Scripts', true],
  ['Create [// TODO: Config file name]', 'createConfig', 'Config', true],
  ['Create [// TODO: Ignore file name]', 'addIgnores', 'Ignores', true]
] as const satisfies SimplifiedChoices;

export const QUESTION = (key: string) => {
  return createCheckbox(
    key,
    'Please check the item(s) you need',
    massageChoices(CHOICES).map(createCheckboxChoice)
  );
};
