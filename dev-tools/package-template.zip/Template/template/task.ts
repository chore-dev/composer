import { getAnswers } from '../../../src/store/answers.store';

import addIgnores from './addIgnores';
import createConfig from './createConfig';
import insertScripts from './insertScripts';
import install from './install';

export const TASK = () => {
  const { '// TODO: Template key': template } = getAnswers();

  if (template) {
    if (template.addIgnores) addIgnores();
    if (template.createConfig) createConfig();
    if (template.insertScripts) insertScripts();
    if (template.install) install();
  }
};
