const createConfig = () => {
  // TODO: Create config
};

export default createConfig;
