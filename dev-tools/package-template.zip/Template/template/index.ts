import { CheckboxQuestionOptions } from 'inquirer';

import { CheckboxAnswers, Choice, Collection } from '../../../types';

import { CHOICES, QUESTION } from './question';
import { TASK } from './task';

export const KEY = '// TODO: Template key' as const;

const TEMPLATE = {
  KEY,
  CHOICES,
  QUESTION: QUESTION(KEY),
  TASK
} as const satisfies Collection<CheckboxQuestionOptions>;

export default TEMPLATE;

export type TEMPLATE_ANSWER = CheckboxAnswers<Choice<typeof TEMPLATE>>;
