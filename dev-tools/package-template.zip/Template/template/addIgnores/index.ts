const addIgnores = () => {
  // TODO: Add ignores
};

export default addIgnores;
