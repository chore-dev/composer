const insertScripts = () => {
  // TODO: Insert scripts
};

export default insertScripts;
