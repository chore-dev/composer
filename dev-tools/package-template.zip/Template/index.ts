import { Prettify } from '@chore-dev/utility-types';
import inquirer from 'inquirer';

import { getAnswers } from '../../src/store/answers.store';
import { isValidCheckboxAnswer } from '../../src/utilities/is';
import { section, sectionWithConfirmation } from '../../src/utilities/section';

import TEMPLATE, { KEY, TEMPLATE_ANSWER } from './template';

const TITLE = '// TODO: Template title';

export const templateQuestions = () => {
  return sectionWithConfirmation(
    TITLE,
    async () => (await inquirer.prompt([TEMPLATE.QUESTION])) as TEMPLATE_ANSWERS,
    () => ({ [KEY]: false })
  );
};

export const templateTasks = () => {
  return section(TITLE, isValidCheckboxAnswer(getAnswers()[KEY]) && TEMPLATE.TASK);
};

export type TEMPLATE_ANSWERS = Record<typeof KEY, Prettify<TEMPLATE_ANSWER> | false>;
